import React from "react";
import { Link } from "react-router-dom";
import dcca from "./image/dcca.png"

let Footer = () => {
    return(
        <>
        <footer className="container-fluid mt-5 justify-content-center text-dark">
            <div className="row justify-content-center p-5">
                <div className="col-12">
                    <div className="row ">
                        <div className="col-md-3 col-sm-12 col-xs-12 col-lg-3 col-auto">
                            <img src={dcca} width="50%" alt=""/>
                        </div>
                        <div className="col-md-3 col-sm-12 col-xs-12 col-lg-3 col-auto">
                            <h6 className="mb-3 mb-lg-4 bold-text text-light"><b>MENU</b></h6>
                            <ul className="list-unstyled">
                                <Link to="/about" style={{textDecoration:"none",color:"white"}}><li>About</li>
                                </Link>
                                <Link to="/achievement" style={{textDecoration:"none",color:"white"}}><li>Achievements</li>
                                </Link>
                                <Link to="/coaches" style={{textDecoration:"none",color:"white"}}><li>Coaches</li>
                                </Link>
                                <Link to="/contact" style={{textDecoration:"none",color:"white"}}><li>Contact Us</li>
                                </Link>
                            </ul>
                        </div>
                        <div className="col-md-3 col-sm-12 col-xs-12 col-lg-3 col-auto text-light">
                            <h6 className="mb-3 mb-lg-4 bold-text"><b>ADDRESS</b></h6>
                            <p className="mb-1">Behind Reshmai Naturopathy,</p>
                            <p>Dream City Society, Maloni</p>
                        </div>
                        <div className="col-md-3 col-sm-12 col-xs-12 col-lg-3 col-auto text-light">
                          <small className="rights text-center"><span>&#174;</span> Dream City Cricket Academy | All Rights Reserved.</small>
                        <p className="text-light">Copyright &copy; 2019</p>
                        <h6 className="text-light">Follow Us On</h6>
                            <div className="icon bg-light p-2" id="bg-light">
                                <Link to="http://www.instagram.com/dreamcitycric"><i className="fab fa-instagram-square text-danger fa-2x"></i></Link> &nbsp;&nbsp;&nbsp;
                                <Link to="http://www.facebook.com/dreamcitycric"><i className="fab fa-facebook-square text-primary fa-2x"></i></Link> &nbsp;&nbsp;&nbsp;
                                <Link to="http://www.Whatsapp.com"><i className="fab fa-whatsapp-square text-success fa-2x"></i></Link>
                                &nbsp;&nbsp;&nbsp;
                                <Link to=""><i class="fab fa-linkedin text-info fa-2x"></i></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        </>
    );
}
export default Footer;